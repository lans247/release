using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class quater : MonoBehaviour
{
    public int c;

    public GameObject target;
    public Vector3 target_po;

    public float speed;
    public float range;
    public string proper; //�Ӽ�

    public GameObject bullet;
    public float attack_speed;

    public int damage = 1; //�Ѿ� ������

    // Start is called before the first frame update
    void Start()
    {
        bullet_set(damage, 0.1f, proper);

        target = GameObject.FindWithTag("Player");
        range = Random.Range(9, 12);
        proper = this.gameObject.GetComponent<enemy>().proper;

        StartCoroutine(attack(5f - attack_speed));
    }

    void bullet_set(int da, float spee, string pro)
    {
        bullet.GetComponent<gbullet>().damage = da;
        bullet.GetComponent<gbullet>().proper = pro;
        bullet.GetComponent<gbullet>().master = this.gameObject;
        bullet.GetComponent<gbullet>().shooting = spee;
    }

    // Update is called once per frame
    void FixedUpdate()
    {
        proper = this.gameObject.GetComponent<enemy>().proper;
        damage = this.gameObject.GetComponent<enemy>().damage;
        target = this.gameObject.GetComponent<enemy>().target;
        target_po = this.gameObject.GetComponent<enemy>().target_po; //Ÿ����ġ
        attack_speed = this.gameObject.GetComponent<enemy>().attack_speed;
        speed = this.gameObject.GetComponent<enemy>().speed;

        move();
    }


    void move()
    {

        if (target_po != null)
        {
            this.transform.LookAt(target_po);
            if (Vector3.Distance(this.gameObject.transform.position, target_po) > range)
            {
                this.transform.Translate(new Vector3(0f, 0f, speed));
            }
        }
        //else if (Vector3.Distance(this.transform.position, target.transform.position) < range - 2)
        //{
        //    if (c == 1) { this.transform.Translate(new Vector3(speed, 0f, -speed + 0.02f)); }
        //    else { this.transform.Translate(new Vector3(-speed, 0f, -speed + 0.02f)); }
        //}
        else
        {
            if (c == 1) { this.transform.Translate(new Vector3(speed, 0f, 0f)); }
            else { this.transform.Translate(new Vector3(-speed, 0f, 0f)); }
        }
    }



    IEnumerator attack(float attack_shell)
    {
        Vector3 shotp;
        Quaternion asap;
        int patern = Random.Range(0, 3);
        
        if (patern == 0) //����1
        {
            if (Vector3.Distance(this.gameObject.transform.position, target_po) <= range)
            {
                for (int j = 0; j < 8; j++)
                {
                    for (int i = 0; i < 8; i++)
                    {
                        if (j == 0 || j == 7 || i == 0 || i == 7)
                        {
                            shotp = new Vector3(this.gameObject.transform.position.x + i - 3, this.gameObject.transform.position.y, this.gameObject.transform.position.z);
                            bullet_set(5, 0.15f, proper);
                            Instantiate(bullet, shotp, this.gameObject.transform.rotation);
                        }
                    }
                    yield return new WaitForSeconds(0.1f);
                }
            }
        }
        else if (patern == 1) //����2
        {
            if (Vector3.Distance(this.gameObject.transform.position, target_po) <= range)
            {
                this.gameObject.GetComponent<enemy>().stunh += 1;
                for (int j = 0; j < 10; j++)
                {
                    shotp = new Vector3(this.gameObject.transform.position.x, this.gameObject.transform.position.y, this.gameObject.transform.position.z);
                    bullet_set((int)(damage*0.1f), 0.4f, proper);
                    Instantiate(bullet, shotp, this.gameObject.transform.rotation);
                    yield return new WaitForSeconds(0.1f);
                }
            }
        }
        else if (patern == 2) //����3
        {
            if (Vector3.Distance(this.gameObject.transform.position, target_po) <= range)
            {
                this.gameObject.GetComponent<enemy>().stunh += 1;
                for (int j = 0; j < 20; j++)
                {
                    shotp = new Vector3(this.gameObject.transform.position.x, this.gameObject.transform.position.y, this.gameObject.transform.position.z);
                    asap = Quaternion.Euler(this.gameObject.transform.rotation.x, this.gameObject.transform.rotation.y + 18 * j, this.gameObject.transform.rotation.z);
                    bullet_set(damage, 0.2f, proper);
                    Instantiate(bullet, shotp, asap);
                }
            }
        }
        yield return new WaitForSeconds(attack_shell);
        StartCoroutine(attack(5f - attack_speed));
    }
}
