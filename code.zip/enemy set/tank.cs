﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class tank : MonoBehaviour
{
    public GameObject target;
    public Vector3 target_po;

    public bool at_check = true;

    public float speed;
    public float range;

    public float attack_speed;
    // Start is called before the first frame update
    void Start()
    {
        range = Random.Range(1, 3);
        target = GameObject.FindGameObjectWithTag("Player");
        attack_speed = this.gameObject.GetComponent<enemy>().attack_speed;
        speed = this.gameObject.GetComponent<enemy>().speed;
        move();
    }

    // Update is called once per frame
    void FixedUpdate()
    {
        target_po = this.GetComponent<enemy>().target_po;
        speed = this.GetComponent<enemy>().speed;
        move();
        attack_check();
    }

    void attack_check()
    {
        if (target != null)
        {
            if (at_check && Vector3.Distance(this.gameObject.transform.position, target.transform.position) <= range) //타겟이 적이고, 공격 쿨타임이 true이며, 거리가 사거리 안 일때
                attack();
        }
    }

    IEnumerator attack_speed_check()
    {
        float attack_cool = 5.0f - attack_speed; //공속 기반 다음 공격까지 걸리는 시간.
        yield return new WaitForSeconds(attack_cool);
        at_check = true;
    }
    void attack() //공격
    {
        at_check = false; // 공격 쿨타임.
        target.GetComponent<Rigidbody>().AddRelativeForce(0f, 0f, -150f, ForceMode.Impulse); //밀기 만 함

        StartCoroutine(attack_speed_check()); //공격 쿨타임 대기        
    }

    void move()
    {
        if (target_po != null)
        {
            this.transform.LookAt(target_po);
            if (Vector3.Distance(this.transform.position, target_po) >= range)
            {
                this.transform.Translate(new Vector3(0f, 0f, speed));
            }
        }
    }
}
