using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class magician : MonoBehaviour
{
    public GameObject target;
    public Vector3 target_po;

    public float speed;
    public float range;

    public GameObject bullet;
    public float attack_speed;

    public int damage = 5;
    public string proper;

    // Start is called before the first frame update
    void Start()
    {
        target = GameObject.FindGameObjectWithTag("Player");
        range = Random.Range(20, 25);

        proper = this.gameObject.GetComponent<enemy>().proper;
        StartCoroutine(attack(8f - attack_speed));

        StartCoroutine(tel()); //teleport code for magician
    }

    // Update is called once per frame
    void FixedUpdate()
    {
        proper = this.gameObject.GetComponent<enemy>().proper;
        damage = this.gameObject.GetComponent<enemy>().damage;

        target_po = this.GetComponent<enemy>().target_po;
        attack_speed = this.GetComponent<enemy>().attack_speed;
        speed = this.GetComponent<enemy>().speed; //������, ������ Ŭ�󽺴� ���� ����
        target = this.GetComponent<enemy>().target;

        this.transform.LookAt(target_po); //look target - to shoot bullet
    }
    void bullet_set(int da, float spee, string pro)
    {
        bullet.GetComponent<gbullet>().damage = da;
        bullet.GetComponent<gbullet>().proper = pro;
        bullet.GetComponent<gbullet>().master = this.gameObject;
        bullet.GetComponent<gbullet>().shooting = spee;
    }

    IEnumerator attack(float attack_shell)
    {
        Vector3 core;  //�Ѿ��� ��ġ bullet position
        Quaternion asap;  //�Ѿ��� ���� bullet angle
        int patern = Random.Range(0, 3);  //���� ���� //random partern
        float how; //�Ѿ��� ���� ������ ���� �ʿ��� �Ҽ� //using for partern
        int dam; //������ ������ ������(�� ������ ���) //real damage

        if (patern == 0)
        {
            if (Vector3.Distance(this.transform.position, target_po) <= range) // �Ÿ��� ��ȿ��Ÿ� �̳��� ���
            {
                for (int i = 0; i < 180; i++)
                {
                    dam = (int)(damage * 0.5f);
                    how = 2*i;
                    core = new Vector3(this.transform.position.x + 3 * Mathf.Cos(how), this.transform.position.y, this.transform.position.z + 3 * Mathf.Sin(how));
                    bullet_set(dam, 0.1f, proper);
                    Instantiate(bullet, core, this.transform.rotation);
                }
            }
        }

        else if(patern == 1)
        {
            if (Vector3.Distance(this.transform.position, target_po) >= range) // �Ÿ��� ��ȿ��Ÿ� ���� ���
            {
                for (int i = 0; i < 360; i++)
                {
                    dam = (int)(damage * 0.2f);
                    how = i;
                    core = new Vector3(this.transform.position.x + 4 * Mathf.Cos(how), this.transform.position.y, this.transform.position.z + 4 * Mathf.Sin(how));
                    bullet_set(dam, 0.1f, proper);
                    Instantiate(bullet, core, this.transform.rotation);
                    yield return new WaitForSeconds(0.001f);
                }
            }
        }
        yield return new WaitForSeconds(attack_shell);
        StartCoroutine(attack(attack_shell));
    }

    IEnumerator tel()
    {
        float x_pp, y_pp;
        x_pp = Random.Range(-20, 20);
        y_pp = Random.Range(-25, 25);
        this.transform.position = new Vector3(x_pp, 0.2f, y_pp);
        yield return new WaitForSeconds(2 - speed);
        StartCoroutine(tel());
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("background"))
        {
            Debug.Log("�浹");
            this.transform.Translate(new Vector3(speed, 0f, 0f));
        }
    }
}
