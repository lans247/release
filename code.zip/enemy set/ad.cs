﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ad : MonoBehaviour
{
    public bool at_check = true; //공격 체크, True일때 공격가능. False일때 대기시간.

    public GameObject target;
    public Vector3 target_po; 

    public float speed;
    public float range;
    public string proper; //속성

    public GameObject abullet;
    public float attack_speed;

    public int damage = 1; //총알 데미지

    public int c;

    // Start is called before the first frame update
    void Start()
    {
        c = Random.Range(1, 3);
        target = GameObject.FindWithTag("Player");
        range = Random.Range(9, 12);

        proper = this.gameObject.GetComponent<enemy>().proper;
    }

    void bullet_set(int da, float spee, string pro)
    {
        abullet.GetComponent<gbullet>().damage = da;
        abullet.GetComponent<gbullet>().proper = pro;
        abullet.GetComponent<gbullet>().master = this.gameObject;
        abullet.GetComponent<gbullet>().shooting = spee;
    }

    // Update is called once per frame
    void FixedUpdate()
    {
        proper = this.gameObject.GetComponent<enemy>().proper;
        damage = this.gameObject.GetComponent<enemy>().damage;

        target = this.gameObject.GetComponent<enemy>().target;
        target_po = this.gameObject.GetComponent<enemy>().target_po; //타겟위치
        attack_speed = this.gameObject.GetComponent<enemy>().attack_speed; 
        speed = this.gameObject.GetComponent<enemy>().speed;
        move();

        attack_check();
    }

    void attack_check()
    {
        if (target != null)
        {
            if (at_check && Vector3.Distance(this.gameObject.transform.position, target.transform.position) <= range) //타겟이 적이고, 공격 쿨타임이 true이며, 거리가 사거리 안 일때
                StartCoroutine(attack());
        }
    }

    IEnumerator attack_speed_check()
    {
        float attack_cool = 5.0f - attack_speed; //공속 기반 다음 공격까지 걸리는 시간.
        yield return new WaitForSeconds(attack_cool);
        at_check = true;
    }

    void move()
    {
        if (target_po != null)
        {
            this.transform.LookAt(target_po);
            if (Vector3.Distance(this.gameObject.transform.position, target_po) > range)
            {
                this.transform.Translate(new Vector3(0f, 0f, speed));
            }
        }
        //else if (Vector3.Distance(this.transform.position, target.transform.position) < range - 2)
        //{
        //    if (c == 1) { this.transform.Translate(new Vector3(speed, 0f, -speed + 0.02f)); }
        //    else { this.transform.Translate(new Vector3(-speed, 0f, -speed + 0.02f)); }
        //}
        else
        {
            if (c == 1) { this.transform.Translate(new Vector3(speed, 0f, 0f)); }
            else { this.transform.Translate(new Vector3(-speed, 0f, 0f)); }
        }
    }

    IEnumerator attack() //공격
    {
        at_check = false; // 공격 쿨타임.
        for (int i = 0; i < 4; i++)
        {
            bullet_set(damage, 0.1f, proper);
            Instantiate(abullet, this.gameObject.transform.position, this.gameObject.transform.rotation);
            yield return new WaitForSeconds(0.4f);
        }
        c = Random.Range(1, 2);
        StartCoroutine(attack_speed_check()); //공격 쿨타임 대기        
    }

    private void OnTriggerEnter(Collider other)
    {
        if(other.CompareTag("background"))
        {
            if (c == 1) { c = 2; }
            else { c = 1; }
        }
    }
}

