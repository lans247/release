﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class sniper : MonoBehaviour
{
    public bool at_check = true; //공격 체크, True일때 공격가능. False일때 대기시간.

    public GameObject target;
    public Vector3 target_po;

    public float speed;
    public float range;

    public GameObject sbullet;
    public float attack_speed;

    public int damage = 5;
    public string proper;

    // Start is called before the first frame update
    void Start()
    {
        target = GameObject.FindGameObjectWithTag("Player");
        range = Random.Range(25, 30);

        proper = this.gameObject.GetComponent<enemy>().proper;
    }

    // Update is called once per frame
    void FixedUpdate()
    {
        proper = this.gameObject.GetComponent<enemy>().proper;
        damage = this.gameObject.GetComponent<enemy>().damage;
        target_po = this.GetComponent<enemy>().target_po;
        attack_speed = this.GetComponent<enemy>().attack_speed;
        speed = this.GetComponent<enemy>().speed;
        target = this.GetComponent<enemy>().target;
        move();

        attack_check();
    }
    void bullet_set(int da, float spee, string pro)
    {
        sbullet.GetComponent<gbullet>().damage = da;
        sbullet.GetComponent<gbullet>().proper = pro;
        sbullet.GetComponent<gbullet>().master = this.gameObject;
        sbullet.GetComponent<gbullet>().shooting = spee;
    }
    

    void attack_check()
    {
        if (target != null)
        {
            if (at_check && Vector3.Distance(this.gameObject.transform.position, target.transform.position) <= range) //타겟이 적이고, 공격 쿨타임이 true이며, 거리가 사거리 안 일때
                attack();
        }
    }

    IEnumerator attack_speed_check()
    {
        float attack_cool = 5.0f - attack_speed; //공속 기반 다음 공격까지 걸리는 시간.
        yield return new WaitForSeconds(attack_cool);
        at_check = true;
    }


    void attack()
    {
        at_check = false; // 공격 쿨타임
        bullet_set(damage, 0.2f, proper);
        Instantiate(sbullet, this.transform.position, this.transform.rotation);

        StartCoroutine(attack_speed_check());
    }

    void move()
    {
        if (target_po != null)
        {
            this.gameObject.transform.LookAt(target_po);
            if (Vector3.Distance(this.transform.position, target_po) > range)
            {
                this.transform.Translate(new Vector3(0f, 0f, speed));
            }
        }
        //else if (Vector3.Distance(this.transform.position, target.transform.position) < range - 15)
        //{
        //    this.transform.Translate(new Vector3(0f, 0f, -speed));
        //}
    }

    private void OnTriggerEnter(Collider other)
    {
        if(other.CompareTag("background"))
        {
            Debug.Log("충돌");
            this.transform.Translate(new Vector3(speed, 0f, 0f));
        }
    }
}
