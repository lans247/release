using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class arrow : MonoBehaviour
{
    public GameObject player;


    void Start()
    {
        player = GameObject.Find("player_c");
    }
    // Update is called once per frame
    void Update()
    {
        if (player == null)
        {
            Destroy(this.gameObject);
        }
        else
        {
            if (player.GetComponent<player>().target != gameObject)
            {
                Destroy(this.gameObject);
            }
        } 
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.tag == "Player")
        {
            Destroy(this.gameObject);
        }
    }

}
